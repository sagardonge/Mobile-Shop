package com.mobile.MobileShop.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.ModelAndView;

import com.mobile.MobileShop.entity.Mobile;
import com.mobile.MobileShop.service.Service;

@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	Service ss;

	 @PostMapping("/datainsert")
	 public String insertdata(@RequestBody Mobile mob) {
	
	
	 return ss.insertdata(mob);
	
	 }
	

	@GetMapping("/getalldata")
	public ModelAndView getalldata() {

		ModelAndView view = new ModelAndView();
		view.setViewName("home");

		List<Mobile> list = ss.getalldata();
		view.addObject("alldata", list);
		return view;

	}

	@PutMapping("/updatecompeny/{id}/{compeny}")
	public String updatebyid(@PathVariable int id, @PathVariable String compeny) {

		String msg = ss.updatecompeny(id, compeny);
		return msg;

	}

	@PutMapping("/updatecolor/{id}/{color}")
	public String updatecolor(@PathVariable int id, @PathVariable String color) {
		String msg = ss.updatecolor(id, color);
		return msg;
	}

	@PutMapping("updatemodel/{id}/{model}")
	public String updatemodel(@PathVariable int id, @PathVariable String model) {

		String msg = ss.updatemodel(id, model);
		return msg;
	}

	@PutMapping("/updateprice/{id}/{price}")
	public String updateprice(@PathVariable int id, @PathVariable double price) {

		String msg = ss.updateprice(id, price);
		return msg;
	}

	@PutMapping("/updatesell/{id}/{sell}")
	public String updatesell(@PathVariable int id, @PathVariable int sell) {

		String msg = ss.updatesell(id, sell);
		return msg;
	}

	@PutMapping("updatestock/{id}/{stock}")
	public String updatestock(@PathVariable int id, @PathVariable int stock) {
		String msg = ss.updatestock(id, stock);
		return msg;
	}

	@GetMapping("/gtprice/{price}")
	public List<Mobile> greaterthan(@PathVariable double price) {

		List<Mobile> list = ss.greaterthan(price);
		return list;
	}

	@GetMapping("/gtid/{id}")
	public List<Mobile> gtId(@PathVariable int id) {
		List<Mobile> list = ss.gtId(id);
		return list;

	}

	@GetMapping("/gtmodel/{model}")
	public List<Mobile> gtmodel(@PathVariable String model) {
		List<Mobile> list = ss.gtmodel(model);
		return list;
	}

	@GetMapping("gtcolor/{color}")
	public List<Mobile> gtcolor(@PathVariable String color) {
		List<Mobile> list = ss.gtcolor(color);
		return list;
	}

	@GetMapping("gtsell/{sell}")
	public List<Mobile> gtsell(@PathVariable int sell) {
		List<Mobile> list = ss.gtsell(sell);
		return list;
	}

	@GetMapping("gtstock/{stock}")
	public List<Mobile> gtstock(@PathVariable int stock) {
		List<Mobile> list = ss.gtstock(stock);
		return list;
	}

	@GetMapping("/ltprice/{price}")
	public List<Mobile> lessthan(@PathVariable double price) {

		List<Mobile> list = ss.lessthan(price);
		return list;
	}

	@GetMapping("/ltcolor/{color}")
	public List<Mobile> ltcolor(@PathVariable String color) {

		List<Mobile> list = ss.ltcolor(color);
		return list;
	}

	@GetMapping("/etcolor/{color}")
	public List<Mobile> Equaltocolor(@PathVariable String color) {

		List<Mobile> list = ss.Equaltocolor(color);
		return list;
	}

	@GetMapping("/etcompeny/{comp}")
	public List<Mobile> Equaltocompeny(@PathVariable String comp) {

		List<Mobile> list = ss.Equaltocompeny(comp);
		return list;
	}

	@GetMapping("/ltmodel/{model}")
	public List<Mobile> ltmodel(@PathVariable String model) {

		List<Mobile> list = ss.ltmodel(model);
		return list;
	}

	@GetMapping("/ltsell/{sell}")
	public List<Mobile> ltsell(@PathVariable int sell) {

		List<Mobile> list = ss.ltsell(sell);
		return list;
	}

	@GetMapping("/ltstock{stock}")
	public List<Mobile> ltstock(@PathVariable int stock) {

		List<Mobile> list = ss.ltstock(stock);
		return list;
	}

	@GetMapping("/etprice/{price}")
	public List<Mobile> equalto(@PathVariable double price) {

		List<Mobile> list = ss.equlto(price);
		return list;
	}

	@GetMapping("netprice/{price}")
	public List<Mobile> notequalto(@PathVariable double price) {
		List<Mobile> list = ss.notequalto(price);
		return list;
	}

	@GetMapping("gtetprice/{price}")
	public List<Mobile> greaterthanequlto(@PathVariable double price) {
		List<Mobile> list = ss.greaterthanequalto(price);
		return list;
	}

	@GetMapping("ltetprice/{price}")
	public List<Mobile> lessthanequalto(@PathVariable double price) {
		List<Mobile> list = ss.lessthanequalto(price);
		return list;
	}

	@GetMapping("betweenprice/{price1}/{price2}")
	public List<Mobile> betweenprice(@PathVariable double price1, @PathVariable double price2) {
		List<Mobile> list = ss.betweenprice(price1, price2);
		return list;

	}

	@GetMapping("betweencompney/{compeny}/{compeny1}")
	public List<Mobile> betweencompeny(@PathVariable String compeny, @PathVariable String compeny1) {

		return ss.betweencompeny(compeny, compeny1);
	}

	@DeleteMapping("deletebyid/{id}")
	public String deletebyid(@PathVariable int id) {

		String msg = ss.deletebyid(id);
		return msg;
	}

	@DeleteMapping("/deletecolor/{color}/{color1}")
	public String deletebetweencolor(@PathVariable String color, @PathVariable String color1) {
		String msg = ss.deletebetweencolor(color, color1);
		return msg;
	}

	@GetMapping("/byid/{id}")
	public List<Mobile> byid(@PathVariable int id) {
		List<Mobile> list = ss.byid(id);
		return list;
	}

	@GetMapping("/bycompeny/{comp}")
	public List<Mobile> bycompeny(@PathVariable String comp) {

		List<Mobile> list = ss.bycompeny(comp);
		return list;

	}

}
