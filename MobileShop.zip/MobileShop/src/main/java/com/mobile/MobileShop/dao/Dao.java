package com.mobile.MobileShop.dao;



import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mobile.MobileShop.entity.Mobile;

@Repository
public class Dao  {

	@Autowired
	SessionFactory sf;

	// 1) insert data
	public String insertdata(Mobile mob) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();

		session.save(mob);

		tr.commit();
		session.close();
		return "Data Saved...";

	}

	// 2) getall data
	public List<Mobile> getalldata() {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		return ctr.list();
	}

	// 3) update compeny

	public String updatecompeny(int id, String compeny) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		mm.setCompeny(compeny);

		session.update(mm);
		tr.commit();
		session.close();
		return "Data updated";
	}

	// 4) update color
	public String updatecolor(int id, String color) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		mm.setColor(color);

		session.update(mm);
		tr.commit();
		session.close();
		return "Data Updated..";

	}

	// 6 update model
	public String updatemodel(int id, String model) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		mm.setModel(model);

		session.update(mm);

		tr.commit();
		session.close();

		return "Model Updated....";

	}

	// 7) update price

	public String updateprice(int id, double price) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		mm.setPrice(price);
		session.update(mm);
		tr.commit();
		session.close();
		return "Price Update..";

	}

	// 8) update sell

	public String updatesell(int id, int sell) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		mm.setSell(sell);

		session.update(mm);
		tr.commit();
		session.close();
		return "Sell Update..";

	}

	// 9) update stock

	public String updatestock(int id, int stock) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		mm.setStock(stock);
		session.update(mm);
		tr.commit();
		session.close();
		return "Stock Update...";

	}

	// 10) Greater Than

	public List<Mobile> greaterthan(double price) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.gt("price", price)).list();
		return list;

	}

	// 11) greater than id

	public List<Mobile> gtId(int id) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.gt("id", id)).list();
		return list;
	}

	// 12) greter than model

	public List<Mobile> gtmodel(String model) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.gt("model", model)).list();
		return list;
	}

	// 13) Greater than color

	public List<Mobile> gtcolor(String color) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.gt("color", color)).list();
		return list;
	}

	// 14) Greate than sell

	public List<Mobile> gtsell(double sell) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.gt("sell", sell)).list();
		return list;
	}
	// 15) Greate than stock

	public List<Mobile> gtstock(double stock) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.gt("stock", stock)).list();
		return list;
	}

	// 16) less than price
	public List<Mobile> lessthan(double price) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.lt("price", price)).list();
		return list;
	}

	// 17) less than color
	public List<Mobile> ltcolor(String color) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.lt("color", color)).list();
		return list;
	}

	// 18) Equal to color

	public List<Mobile> Equaltocolor(String color) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		ctr.add(Restrictions.eq("color", color));
		List<Mobile> list = ctr.list();
		return list;
	}

	// Equl to compeny

	public List<Mobile> Equaltocompeny(String comp) {

		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Mobile.class);
		criteria.add(Restrictions.eq("compeny", comp));
		List<Mobile> list = criteria.list();
		return list;
	}

	// 19) less than model
	public List<Mobile> ltmodel(String model) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.lt("model", model)).list();
		return list;
	}

	// 20) less than sell
	public List<Mobile> ltsell(double sell) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.lt("sell", sell)).list();
		return list;
	}

	// 21) less than stock
	public List<Mobile> ltstock(double stock) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.lt("stock", stock)).list();
		return list;
	}
	// 22) greaterthan Equalto

	public List<Mobile> greaterthanequalto(double price) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.ge("price", price)).list();
		return list;
	}

	// 23) lessthan Equalto
	public List<Mobile> lessthanequalto(double price) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.le("price", price)).list();
		return list;
	}

	// 24) Equal to

	public List<Mobile> equalto(double price) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.eqOrIsNull("price", price)).list();
		return list;
	}

	// 25) Not equal to

	public List<Mobile> notequalto(double price) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.ne("price", price)).list();
		return list;
	}

	// 26) between price
	public List<Mobile> betweenprice(double price1, double price2) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.between("price", price1, price2)).list();
		session.close();
		return list;

	}

	// 27) betweencompeny pendding

	public List<Mobile> betweencompeny(String compeny, String compeny1) {
		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		ctr.add(Restrictions.between("compeny", compeny, compeny1));
		List<Mobile> list = ctr.list();

		session.close();
		return list;
	}

	// 28) delete by id

	public String deletebyid(int id) {

		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Mobile mm = session.get(Mobile.class, id);
		session.delete(mm);

		tr.commit();
		session.close();
		return "Data Deleted...";

	}

	// 29) delete between color

	public String deletebetweencolor(String color, String color1) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Criteria ctr = session.createCriteria(Mobile.class);
		List<Mobile> list = ctr.add(Restrictions.between("color", color, color1)).list();
		for (Mobile obj : list) {
			session.delete(obj);

		}
		tr.commit();
		session.close();
		return "data deleted..";

	}
	// 30) by id

	public List<Mobile> byid(int id) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		ctr.add(Restrictions.eq("id", id));
		List<Mobile> list = ctr.list();
		return list;
	}

	// 30) by compeny

	public List<Mobile> bycompeny(String compeny) {

		Session session = sf.openSession();
		Criteria ctr = session.createCriteria(Mobile.class);
		ctr.add(Restrictions.eqOrIsNull("compeny", compeny));
		List<Mobile> list = ctr.list();

		return list;
	}

}
