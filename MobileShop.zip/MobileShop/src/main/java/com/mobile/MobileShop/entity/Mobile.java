package com.mobile.MobileShop.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Mobile {

	
	private int id;
	private String compeny;
	private String model;
	private String color;
	private double price;
	private int stock;
	private int sell;

	public Mobile() {

	}

	public Mobile(int id, String compeny, String model, String color, double price, int stock, int sell) {
		super();
		this.id = id;
		this.compeny = compeny;
		this.model = model;
		this.color = color;
		this.price = price;
		this.stock = stock;
		this.sell = sell;
	}

	@Id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCompeny() {
		return compeny;
	}

	public void setCompeny(String compeny) {
		this.compeny = compeny;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getSell() {
		return sell;
	}

	public void setSell(int sell) {
		this.sell = sell;
	}

	@Override
	public String toString() {
		return "Mobile [id=" + id + ", compeny=" + compeny + ", model=" + model + ", color=" + color + ", price="
				+ price + ", stock=" + stock + ", sell=" + sell + "]";
	}

}
