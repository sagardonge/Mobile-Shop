package com.mobile.MobileShop.reposetory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.mobile.MobileShop.entity.Mobile;

public interface UserReposetory extends JpaRepository<Mobile, Long>{

}
