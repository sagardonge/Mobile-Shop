
package com.mobile.MobileShop.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import com.mobile.MobileShop.dao.Dao;
import com.mobile.MobileShop.entity.Mobile;


@org.springframework.stereotype.Service
public class Service {

	@Autowired
	Dao dd;

	public String insertdata(Mobile mob) {
				return dd.insertdata(mob);
	}

	public List<Mobile> getalldata() {
		return dd.getalldata();
	}

	public String updatecompeny(int id, String compeny) {
		// TODO Auto-generated method stub
		return dd.updatecompeny(id, compeny);
	}

	public String updatecolor(int id, String color) {
		// TODO Auto-generated method stub
		return dd.updatecolor(id, color);
	}

	public String updatemodel(int id, String model) {
		// TODO Auto-generated method stub
		return dd.updatemodel(id, model);
	}

	public String updateprice(int id, double price) {
		// TODO Auto-generated method stub
		return dd.updateprice(id, price);
	}

	public String updatesell(int id, int sell) {
		// TODO Auto-generated method stub
		return dd.updatesell(id, sell);
	}

	public String updatestock(int id, int stock) {
		// TODO Auto-generated method stub
		return dd.updatestock(id, stock);
	}

	public List<Mobile> greaterthan(double price) {
		// TODO Auto-generated method stub
		return dd.greaterthan(price);
	}

	public List<Mobile> gtId(int id) {
		// TODO Auto-generated method stub
		return dd.gtId(id);
	}

	public List<Mobile> gtmodel(String model) {
		// TODO Auto-generated method stub
		return dd.gtmodel(model);
	}

	public List<Mobile> gtcolor(String color) {
		// TODO Auto-generated method stub
		return dd.gtcolor(color);
	}

	public List<Mobile> gtsell(int sell) {
		// TODO Auto-generated method stub
		return dd.gtsell(sell);
	}

	public List<Mobile> gtstock(int stock) {
		// TODO Auto-generated method stub
		return dd.gtstock(stock);
	}

	public List<Mobile> lessthan(double price) {
		// TODO Auto-generated method stub
		return dd.lessthan(price);
	}

	public List<Mobile> ltcolor(String color) {
		// TODO Auto-generated method stub
		return dd.ltcolor(color);
	}

	public List<Mobile> Equaltocolor(String color) {
		// TODO Auto-generated method stub
		return dd.Equaltocolor(color);
	}

	public List<Mobile> Equaltocompeny(String comp) {
		// TODO Auto-generated method stub
		return dd.Equaltocompeny(comp);
	}

	public List<Mobile> ltmodel(String model) {
		// TODO Auto-generated method stub
		return dd.ltmodel(model);
	}

	public List<Mobile> ltsell(int sell) {
		// TODO Auto-generated method stub
		return dd.ltsell(sell);
	}

	public List<Mobile> ltstock(int stock) {
		// TODO Auto-generated method stub
		return dd.ltstock(stock);
	}

	public List<Mobile> equlto(double price) {
		// TODO Auto-generated method stub
		return dd.equalto(price);
	}

	public List<Mobile> notequalto(double price) {
		// TODO Auto-generated method stub
		return dd.notequalto(price);
	}

	public List<Mobile> greaterthanequalto(double price) {
		// TODO Auto-generated method stub
		return dd.greaterthanequalto(price);
	}

	public List<Mobile> lessthanequalto(double price) {
		// TODO Auto-generated method stub
		return dd.lessthanequalto(price);
	}

	public List<Mobile> betweenprice(double price1, double price2) {
		// TODO Auto-generated method stub
		return dd.betweenprice(price1, price2);
	}

	public List<Mobile> betweencompeny(String compeny, String compeny1) {
		// TODO Auto-generated method stub
		return dd.betweencompeny(compeny, compeny1);
	}

	public String deletebyid(int id) {
		// TODO Auto-generated method stub
		return dd.deletebyid(id);
	}

	public String deletebetweencolor(String color, String color1) {
		// TODO Auto-generated method stub
		return dd.deletebetweencolor(color, color1);
	}

	public List<Mobile> byid(int id) {
		// TODO Auto-generated method stub
		return dd.byid(id);
	}

	public List<Mobile> bycompeny(String comp) {
		// TODO Auto-generated method stub
		return dd.bycompeny(comp);
	}


}
